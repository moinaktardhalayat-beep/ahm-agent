"""CLI to manage dashboard users."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import auth


def cmd_add(args):
    data = auth.load_users()
    if args.username in data["users"]:
        print(f"ERROR: user '{args.username}' already exists")
        return 1
    data["users"][args.username] = {
        "username": args.username,
        "display_name": args.display or args.username,
        "role": "admin" if args.admin else "member",
        "password_hash": auth.hash_password(args.password),
    }
    auth.save_users(data)
    print(f"Added user '{args.username}'")
    return 0


def cmd_list(_args):
    data = auth.load_users()
    users = data.get("users", {})
    if not users:
        print("No users. Run add <username> <password> --admin")
        return 0
    print(f"{'username':<20} {'role':<8} {'display_name':<30}")
    print("-" * 60)
    for u in users.values():
        print(f"{u['username']:<20} {u.get('role', 'member'):<8} {u.get('display_name', ''):<30}")
    return 0


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    p_add = sub.add_parser("add")
    p_add.add_argument("username")
    p_add.add_argument("password")
    p_add.add_argument("--admin", action="store_true")
    p_add.add_argument("--display", default="")
    p_add.set_defaults(func=cmd_add)

    sub.add_parser("list").set_defaults(func=cmd_list)

    args = p.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()